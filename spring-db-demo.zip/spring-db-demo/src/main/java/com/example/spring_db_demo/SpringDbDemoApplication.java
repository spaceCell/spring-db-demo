package com.example.spring_db_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDbDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDbDemoApplication.class, args);
	}

}
